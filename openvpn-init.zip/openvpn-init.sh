"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPNConnect" --set-setting=confirmation-dialogs --value=none
"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPNConnect" --set-setting=timeout --value=0
"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPNConnect" --set-setting=launch-options --value=connect-latest