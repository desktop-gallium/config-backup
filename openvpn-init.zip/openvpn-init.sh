ls -lah "/Applications/OpenVPN Connect/"
ls -lah "/Applications/OpenVPN Connect/OpenVPN Connect.app/"
ls -lah "/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/"
ls -lah "/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/"
"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPN Connect" --set-setting=confirmation-dialogs --value=none
"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPN Connect" --set-setting=timeout --value=0
"/Applications/OpenVPN Connect/OpenVPN Connect.app/Contents/MacOS/OpenVPN Connect" --set-setting=launch-options --value=connect-latest